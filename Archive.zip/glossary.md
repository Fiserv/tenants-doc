## Tenant
Is a product that onboards onto the Fiserv Developer Portal (this is our Project PORTAL) to show case it’s APIs and documentation.  For example, Commerce Hub or Business Track.

Note: Tenant use to just mean Carat.  But Carat is a brand not a product as we learned later.

## Solutions
Within the context of our PORTAL a solution is one of the business lines of Fiserv.  Payments, Issuing & Acquiring, Banking & Value Added Services are the 4 major businesses in Fiserv.  As such, we provide solutions around these major areas.

## Products

## Tenant Advocate
Each Tenant is assigned a tenant advocate, a member of Developer Studio. Tenan Advocate acts as Github admin and helps to onboard all files and answer any technical questions.

## 
