# How to Download and Test the Postman Collection

## Download the API Postman Collection
Download the Postman collection on the API explorer page the using the Download Postman Collection button and download the json file in your local which you have to unzip and then you can directly import in your local postman.

<img width="419" alt="image" src="https://user-images.githubusercontent.com/87097017/168697951-d00b6965-7858-4864-8b9d-03c6a4330e16.png">

Import the downloaded json file in the Postman application from your computer.
<img width="1001" alt="image" src="https://user-images.githubusercontent.com/87097017/169099959-97cae31b-7185-4319-b941-f6859eaeab56.png">
<img width="810" alt="image" src="https://user-images.githubusercontent.com/87097017/169101196-bd64a170-5c4d-4247-8263-b1312a24d223.png">



## Prerequiste
Postman

## Getting Started
To get started you can either fork the collection workspace within Postman or import the collection JSON file from this repo.

## Import the collection file into your workspace
If you don't want to fork the collection from the public workspace, you can import it from this repo.

Within your Postman workspace select the Import button

Next copy the downloaded APICollection.json contents and paste in the Paste Raw Text section of the import dialog

## Set your API key

## Make a test call
You should be ready now to make a test call. 



# How Tenant can disable Postman download resource

By default Additional resource will be available in Dev Studio

## Disabling Additional Resource.
Tenant can disable this feature from Github repostitory by updating tenant.json configuration file. 

<img width="419" alt="image" src="https://raw.githubusercontent.com/Fiserv/tenants-doc/1cc2bb18afc75dbf962be60268255a64e1b5d275/images/disable-postman-download.png">
