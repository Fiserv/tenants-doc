All the information related to workflow
